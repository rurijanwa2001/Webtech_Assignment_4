package com.StudentRegistration.StudentRegistration.model;

public enum EQualification {
    MASTER,
    PHD,
    PROFESSOR
}
