package com.StudentRegistration.StudentRegistration.model;

public enum EAcademicUnit {
    PROGRAMME,
    FACULTY,
    DEPARTMENT
}






